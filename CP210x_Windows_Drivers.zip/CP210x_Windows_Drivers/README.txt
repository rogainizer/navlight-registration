This file can be downloaded from http://www.silabs.com/documents/public/software/CP210x_Windows_Drivers.zip. This may be necessary as GMAIL at least will block the mailing of this as an attachment.

Then run appropriate exe